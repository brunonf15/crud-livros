
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.junit.Before;
import org.junit.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class Livros {

	public int idLivro;

	@Before
	public void setup() {
		RestAssured.baseURI = "http://localhost:3000";
		

	}

	private int CriarLivroEspecifico() {

		String requestBody = "{\r\n" + "    \"nome\": \"Livro Rest Assured\",\r\n"
				+ "    \"autor\": \"Bruno Figueiredo\",\r\n" + "    \"paginas\": 250\r\n" + "}";

		idLivro = given().contentType(ContentType.JSON).body(requestBody).

		// usado utilizado para adicionar header ou body por exemplo

				when().
				// acoes

				// http://localhost:3000/livros
				post("/livros")

				.then().statusCode(201)
				// verificar que o id nao esta vazio
				.body("id", notNullValue())

				.body("nome", notNullValue()).body("nome", equalTo("Livro Rest Assured")).body("autor", notNullValue())
				.body("autor", equalTo("Bruno Figueiredo")).body("paginas", notNullValue())
				.body("paginas", equalTo(250))

				.extract().path("id")

		;

		System.out.println("Copiando Id" + idLivro);
		return idLivro;

	}

	@Test
	public void listarTodosLivros() {

		Response response =

				given().
				// usado utilizado para adicionar header ou body por exemplo

						when().
						// acoes

						// http://localhost:3000/livros
						get("/livros")

						.then().statusCode(200).body(notNullValue())

						.extract().response()

		;

		// System.out.println(response.body().asPrettyString());

	}

	@Test
	public void ListarLivroEspecifico() {
		CriarLivroEspecifico();
		Response response =

				given().
				// usado utilizado para adicionar header ou body por exemplo

						when().
						// acoes

						// http://localhost:3000/livros
						get("/livros/"+idLivro)

						.then().statusCode(200)
						// verificar que o id nao esta vazio
						.body("id", notNullValue())
						// assert do id
						.body("id", equalTo(idLivro))

						.body("nome", notNullValue()).body("nome", equalTo("Livro Rest Assured"))
						.body("autor", notNullValue()).body("autor", equalTo("Bruno Figueiredo"))
						.body("paginas", notNullValue()).body("paginas", equalTo(250))

						.extract().response()

		;

		// System.out.println(response.body().asPrettyString());

	}

	@Test
	public void criarLivro() {

		String requestBody = "{\r\n" + "    \"nome\": \"Livro Rest Assured\",\r\n"
				+ "    \"autor\": \"Bruno Figueiredo\",\r\n" + "    \"paginas\": 250\r\n" + "}";

		Response response =

				given().contentType(ContentType.JSON).body(requestBody).

				// usado utilizado para adicionar header ou body por exemplo

						when().
						// acoes

						// http://localhost:3000/livros
						post("/livros")

						.then().statusCode(201)
						// verificar que o id nao esta vazio
						.body("id", notNullValue())

						.body("nome", notNullValue()).body("nome", equalTo("Livro Rest Assured"))
						.body("autor", notNullValue()).body("autor", equalTo("Bruno Figueiredo"))
						.body("paginas", notNullValue()).body("paginas", equalTo(250))

						.extract().response()

		;

		// System.out.println(response.body().asPrettyString());

	}

	@Test
	public void DeletarLivroEspecifico() {
		CriarLivroEspecifico();
		Response response =

				given().
				// usado utilizado para adicionar header ou body por exemplo

						when().
						// acoes

						// http://localhost:3000/livros
						delete("/livros/"+idLivro)

						.then().statusCode(204)

						.extract().response()

		;

		System.out.println(response.body().asPrettyString());

	}

}
